//******************************************************************************
// Copyright (c) 2018, The Regents of the University of California (Regents).
// All Rights Reserved. See LICENSE for license details.
//------------------------------------------------------------------------------
#include "eapp_utils.h"
#include "string.h"
#include "edge_call.h"
#include <syscall.h>
#include "app/syscall.h"
#include <stdio.h>

#define OCALL_PRINT_STRING 1

unsigned long ocall_print_string(char* string);

int main(){

  char config_buf[128];  // Tamaño máximo esperado
  // offset 0 porque el host escribe desde el inicio
  int ret = copy_from_shared(config_buf, 0, sizeof(config_buf));
  config_buf[sizeof(config_buf) - 1] = '\0';
  if(ret != 0){
    ocall_print_string("Error :(");
  }else{
    ocall_print_string(config_buf);
  }
  if(my_strcmp(config_buf, "1") == 0){
    ocall_print_string("My enclave App 1");
  }else{
    ocall_print_string("My enclave App 2");
  }
  

  EAPP_RETURN(0);
}

unsigned long ocall_print_string(char* string){
  unsigned long retval;
  ocall(OCALL_PRINT_STRING, string, strlen(string)+1, &retval ,sizeof(unsigned long));
  return retval;
}

int my_strcmp(const char* s1, const char* s2) {
  while (*s1 && (*s1 == *s2)) {
    s1++;
    s2++;
  }
  return *(const unsigned char*)s1 - *(const unsigned char*)s2;
}
